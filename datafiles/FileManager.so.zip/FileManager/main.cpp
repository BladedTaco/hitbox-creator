#include <string>
#include <fstream>
#include <iostream>
#include <algorithm>
#include <fts.h>
#include <unistd.h>
#include <stdlib.h>
#include <limits.h>
#include <dirent.h>
#include <libgen.h>
#include <sys/stat.h>

using namespace std;

struct dupslash
{
    bool operator()(char a, char b) const
    {
        return (a == '/' && b == '/');
    }
};

string string_replace_all(string str, string substr, string newstr)
{
    size_t pos = 0;
    const size_t sublen = substr.length(), newlen = newstr.length();

    while ((pos = str.find(substr, pos)) != string::npos)
    {
        str.replace(pos, sublen, newstr);
        pos += newlen;
    }

    return str;
}

extern "C"
{
    double file_copy(char *fname, char *newname)
    {
        string str1(fname);
        string str2(newname);

        str1.erase(unique(str1.begin(), str1.end(), dupslash()), str1.end());
        str2.erase(unique(str2.begin(), str2.end(), dupslash()), str2.end());

        int proceed = 0;

        string prestr1 = str1;
        string prestr2 = str2;

        char *cstr1 = (char *)str1.c_str();
        char *cstr2;

        string pardir1(dirname(cstr1));
        if (!pardir1.empty())
        {
            while (*pardir1.rbegin() == '/')
            {
                pardir1.erase(pardir1.size() - 1);
            }
        }
        struct stat pexist1;
        if (stat((char *)pardir1.c_str(), &pexist1) == 0 &&
            S_ISDIR(pexist1.st_mode))
        {
            char actpath1[PATH_MAX + 1];
            char *ptr1 = realpath((char *)pardir1.c_str(), actpath1);
            if (ptr1 != NULL)
            {
                cstr2 = (char *)str2.c_str();
                string pardir2(dirname(cstr2));
                if (!pardir2.empty())
                {
                    while (*pardir2.rbegin() == '/')
                    {
                        pardir2.erase(pardir2.size() - 1);
                    }
                }
                struct stat pexist2;
                if (stat((char *)pardir2.c_str(), &pexist2) == 0 &&
                    S_ISDIR(pexist2.st_mode))
                {
                    char actpath2[PATH_MAX + 1];
                    char *ptr2 = realpath((char *)pardir2.c_str(), actpath2);
                    if (ptr2 != NULL)
                    {
                        proceed = (string(actpath1) == string(actpath2));
                    }
                }
            }
        }

        str1 = prestr1;
        str2 = prestr2;

        cstr1 = (char *)str1.c_str();
        cstr2 = (char *)str2.c_str();

        if ((!proceed) || (proceed && string(basename(cstr1)) != string(basename(cstr2))))
        {
            str1 = prestr1;
            str2 = prestr2;

            struct stat sb1;
            if (stat((char *)str1.c_str(), &sb1) == 0 &&
                S_ISREG(sb1.st_mode))
            {
                double ret = 0;
                size_t sz1 = sb1.st_size;

                ifstream srce((char *)str1.c_str(), ios::binary);
                ret = (srce.tellg() >= 0);

                ofstream dest((char *)str2.c_str(), ios::binary);
                ret = (dest.tellp() >= 0);

                dest << srce.rdbuf();
                ret = (srce.tellg() - dest.tellp() == 0);

                struct stat sb2;
                if (stat((char *)str2.c_str(), &sb2) == 0 &&
                    S_ISREG(sb2.st_mode))
                {
                    size_t sz2 = sb2.st_size;
                    return ((ret == 1) ||
                            (sz1 == 0 && sz2 == 0));
                }
            }
        }

        return 0;
    }

    double file_rename(char *oldname, char *newname)
    {
        string str1(oldname);
        string str2(newname);

        str1.erase(unique(str1.begin(), str1.end(), dupslash()), str1.end());
        str2.erase(unique(str2.begin(), str2.end(), dupslash()), str2.end());

        int proceed = 0;

        string prestr1 = str1;
        string prestr2 = str2;

        char *cstr1 = (char *)str1.c_str();
        char *cstr2;

        string pardir1(dirname(cstr1));
        if (!pardir1.empty())
        {
            while (*pardir1.rbegin() == '/')
            {
                pardir1.erase(pardir1.size() - 1);
            }
        }
        struct stat pexist1;
        if (stat((char *)pardir1.c_str(), &pexist1) == 0 &&
            S_ISDIR(pexist1.st_mode))
        {
            char actpath1[PATH_MAX + 1];
            char *ptr1 = realpath((char *)pardir1.c_str(), actpath1);
            if (ptr1 != NULL)
            {
                cstr2 = (char *)str2.c_str();
                string pardir2(dirname(cstr2));
                if (!pardir2.empty())
                {
                    while (*pardir2.rbegin() == '/')
                    {
                        pardir2.erase(pardir2.size() - 1);
                    }
                }
                struct stat pexist2;
                if (stat((char *)pardir2.c_str(), &pexist2) == 0 &&
                    S_ISDIR(pexist2.st_mode))
                {
                    char actpath2[PATH_MAX + 1];
                    char *ptr2 = realpath((char *)pardir2.c_str(), actpath2);
                    if (ptr2 != NULL)
                    {
                        proceed = (string(actpath1) == string(actpath2));
                    }
                }
            }
        }

        str1 = prestr1;
        str2 = prestr2;

        cstr1 = (char *)str1.c_str();
        cstr2 = (char *)str2.c_str();

        if ((!proceed) || (proceed && string(basename(cstr1)) != string(basename(cstr2))))
        {
            str1 = prestr1;
            str2 = prestr2;

            struct stat sb1;
            struct stat sb2;
            if (stat((char *)str1.c_str(), &sb1) == 0 &&
                S_ISREG(sb1.st_mode) &&
                stat((char *)str2.c_str(), &sb2) != 0)
            {
                return (rename((char *)str1.c_str(), (char *)str2.c_str()) == 0);
            }
        }

        return 0;
    }

    double file_exists(char *fname)
    {
        string str(fname);

        struct stat sb;
        return (stat((char *)str.c_str(), &sb) == 0 &&
                S_ISREG(sb.st_mode));
    }

    double file_delete(char *fname)
    {
        string str(fname);

        struct stat sb;
        if (stat((char *)str.c_str(), &sb) == 0 &&
            S_ISREG(sb.st_mode))
        {
            return (remove((char *)str.c_str()) == 0);
        }

        return 0;
    }

    double directory_create(char *dname)
    {
        string str(dname);

        if (!str.empty())
        {
            while (*str.rbegin() == '/')
            {
                str.erase(str.size() - 1);
            }
        }

        struct stat sb;
        if (stat((char *)str.c_str(), &sb) != 0)
        {
            return (mkdir((char *)str.c_str(), 0777) == 0);
        }

        return 0;
    }

    double directory_copy(char *dname, char *newname)
    {
        string str1(dname);
        string str2(newname);

        str1.erase(unique(str1.begin(), str1.end(), dupslash()), str1.end());
        str2.erase(unique(str2.begin(), str2.end(), dupslash()), str2.end());

        if (!str1.empty())
        {
            while (*str1.rbegin() == '/')
            {
                str1.erase(str1.size() - 1);
            }
        }
        if (!str2.empty())
        {
            while (*str2.rbegin() == '/')
            {
                str2.erase(str2.size() - 1);
            }
        }

        int proceed1 = 0;
        int proceed2 = 0;

        string prestr1 = str1;
        string prestr2 = str2;
        string poststr1 = str1;
        string poststr2 = str2;

        char *cstr1 = (char *)str1.c_str();
        char *cstr2;

        string pardir1(dirname(cstr1));
        if (!pardir1.empty())
        {
            while (*pardir1.rbegin() == '/')
            {
                pardir1.erase(pardir1.size() - 1);
            }
        }

        struct stat pexist1;
        if (stat((char *)pardir1.c_str(), &pexist1) == 0 &&
            S_ISDIR(pexist1.st_mode))
        {
            char actpath1[PATH_MAX + 1];
            char *ptr1 = realpath((char *)pardir1.c_str(), actpath1);
            if (ptr1 != NULL)
            {
                cstr2 = (char *)str2.c_str();
                string pardir2(dirname(cstr2));
                if (!pardir2.empty())
                {
                    while (*pardir2.rbegin() == '/')
                    {
                        pardir2.erase(pardir2.size() - 1);
                    }
                }
                struct stat pexist2;
                if (stat((char *)pardir2.c_str(), &pexist2) == 0 &&
                    S_ISDIR(pexist2.st_mode))
                {
                    char actpath2[PATH_MAX + 1];
                    char *ptr2 = realpath((char *)pardir2.c_str(), actpath2);
                    if (ptr2 != NULL)
                    {
                        char *cpoststr1 = (char *)poststr1.c_str();
                        char *cpoststr2 = (char *)poststr2.c_str();

                        string parbas1(string("/") + basename(cpoststr1));
                        string parbas2(string("/") + basename(cpoststr2));

                        proceed1 = (string(actpath1 + parbas1) != string(actpath2 + parbas2).substr(0, string(actpath1 + parbas1).length()));
                        proceed2 = (string(actpath1) == string(actpath2));
                    }
                }
            }
        }

        str1 = prestr1;
        str2 = prestr2;

        cstr1 = (char *)str1.c_str();
        cstr2 = (char *)str2.c_str();

        if ((proceed1 && !proceed2) || (proceed2 && string(basename(cstr1)) != string(basename(cstr2))))
        {
            str1 = prestr1;
            str2 = prestr2;

            struct stat sb1;
            struct stat sb2;
            if (stat((char *)str1.c_str(), &sb1) == 0 &&
                S_ISDIR(sb1.st_mode) &&
                stat((char *)str2.c_str(), &sb2) != 0)
            {
                if (!directory_create((char *)str2.c_str()))
                    return 0;

                DIR *dir;
                struct dirent *ent;
                if ((dir = opendir((char *)str1.c_str())) != NULL)
                {
                    while ((ent = readdir(dir)) != NULL)
                    {
                        if (ent->d_name != string("."))
                        {
                            if (ent->d_name != string(".."))
                            {
                                string copy_sorc = str1 + "/" + ent->d_name;
                                string copy_dest = str2 + "/" + ent->d_name;

                                struct stat sb3;
                                if (stat((char *)copy_sorc.c_str(), &sb3) == 0 &&
                                    S_ISDIR(sb3.st_mode))
                                {
                                    if (!directory_copy((char *)copy_sorc.c_str(), (char *)copy_dest.c_str()))
                                        return 0;
                                }

                                struct stat sb4;
                                if (stat((char *)copy_sorc.c_str(), &sb4) == 0 &&
                                    S_ISREG(sb4.st_mode))
                                {
                                    if (!file_copy((char *)copy_sorc.c_str(), (char *)copy_dest.c_str()))
                                        return 0;
                                }
                            }
                        }
                    }

                    closedir(dir);
                }
                else
                {
                    return 0;
                }

                return 1;
            }
        }

        return 0;
    }

    double directory_rename(char *oldname, char *newname)
    {
        string str1(oldname);
        string str2(newname);

        str1.erase(unique(str1.begin(), str1.end(), dupslash()), str1.end());
        str2.erase(unique(str2.begin(), str2.end(), dupslash()), str2.end());

        if (!str1.empty())
        {
            while (*str1.rbegin() == '/')
            {
                str1.erase(str1.size() - 1);
            }
        }
        if (!str2.empty())
        {
            while (*str2.rbegin() == '/')
            {
                str2.erase(str2.size() - 1);
            }
        }

        int proceed1 = 0;
        int proceed2 = 0;

        string prestr1 = str1;
        string prestr2 = str2;
        string poststr1 = str1;
        string poststr2 = str2;

        char *cstr1 = (char *)str1.c_str();
        char *cstr2;

        string pardir1(dirname(cstr1));
        if (!pardir1.empty())
        {
            while (*pardir1.rbegin() == '/')
            {
                pardir1.erase(pardir1.size() - 1);
            }
        }
        struct stat pexist1;
        if (stat((char *)pardir1.c_str(), &pexist1) == 0 &&
            S_ISDIR(pexist1.st_mode))
        {
            char actpath1[PATH_MAX + 1];
            char *ptr1 = realpath((char *)pardir1.c_str(), actpath1);
            if (ptr1 != NULL)
            {
                cstr2 = (char *)str2.c_str();
                string pardir2(dirname(cstr2));
                if (!pardir2.empty())
                {
                    while (*pardir2.rbegin() == '/')
                    {
                        pardir2.erase(pardir2.size() - 1);
                    }
                }
                struct stat pexist2;
                if (stat((char *)pardir2.c_str(), &pexist2) == 0 &&
                    S_ISDIR(pexist2.st_mode))
                {
                    char actpath2[PATH_MAX + 1];
                    char *ptr2 = realpath((char *)pardir2.c_str(), actpath2);
                    if (ptr2 != NULL)
                    {
                        char *cpoststr1 = (char *)poststr1.c_str();
                        char *cpoststr2 = (char *)poststr2.c_str();

                        string parbas1(string("/") + basename(cpoststr1));
                        string parbas2(string("/") + basename(cpoststr2));

                        proceed1 = (string(actpath1 + parbas1) != string(actpath2 + parbas2).substr(0, string(actpath1 + parbas1).length()));
                        proceed2 = (string(actpath1) == string(actpath2));
                    }
                }
            }
        }

        str1 = prestr1;
        str2 = prestr2;

        cstr1 = (char *)str1.c_str();
        cstr2 = (char *)str2.c_str();

        if ((proceed1 && !proceed2) || (proceed2 && string(basename(cstr1)) != string(basename(cstr2))))
        {
            str1 = prestr1;
            str2 = prestr2;

            struct stat sb1;
            struct stat sb2;
            if (stat((char *)str1.c_str(), &sb1) == 0 &&
                S_ISDIR(sb1.st_mode) &&
                stat((char *)str2.c_str(), &sb2) != 0)
            {
                return (rename((char *)str1.c_str(), (char *)str2.c_str()) == 0);
            }
        }

        return 0;
    }

    double directory_exists(char *dname)
    {
        string str(dname);

        if (!str.empty())
        {
            while (*str.rbegin() == '/')
            {
                str.erase(str.size() - 1);
            }
        }

        struct stat sb;
        return (stat((char *)str.c_str(), &sb) == 0 &&
                S_ISDIR(sb.st_mode));
    }

    double directory_destroy(char *dname)
    {
        string str(dname);

        if (!str.empty())
        {
            while (*str.rbegin() == '/')
            {
                str.erase(str.size() - 1);
            }
        }

        double ret = 0;

        struct stat sb;
        if (stat((char *)str.c_str(), &sb) == 0 &&
            S_ISDIR(sb.st_mode))
        {
            ret = 1;
            FTS *ftsp = NULL;
            FTSENT *curr;

            char *files[] = {(char *)str.c_str(), NULL};
            ftsp = fts_open(files,  FTS_NOCHDIR | FTS_PHYSICAL | FTS_XDEV,  NULL);
            if (!ftsp)
            {
                ret = 0;
                goto finish;
            }

            while ((curr = fts_read(ftsp)))
            {
                switch (curr->fts_info)
                {
                    case FTS_NS:
                    case FTS_DNR:
                    case FTS_ERR:
                        break;

                    case FTS_DC:
                    case FTS_DOT:
                    case FTS_NSOK:
                        break;

                    case FTS_D:
                        break;

                    case FTS_DP:
                    case FTS_F:
                    case FTS_SL:
                    case FTS_SLNONE:
                    case FTS_DEFAULT:
                        if (remove(curr->fts_accpath) < 0)
                        {
                            ret = 0;
                        }
                        break;
                }
            }

        finish:
            if (ftsp)
            {
                fts_close(ftsp);
            }
        }

        return ret;
    }

    double set_working_directory(char *dname)
    {
        string str(dname);

        if (!str.empty())
        {
            while (*str.rbegin() == '/')
            {
                str.erase(str.size() - 1);
            }
        }

        struct stat sb;
        if (stat((char *)str.c_str(), &sb) == 0 &&
            S_ISDIR(sb.st_mode))
        {
            return (chdir((char *)str.c_str()) == 0);
        }

        return 0;
    }

    char *working_directory()
    {
        char cwd[PATH_MAX + 1];
        if (getcwd(cwd, PATH_MAX + 1) != NULL)
        {
            static string result1;
            static string result2;

            result1 = cwd + string("/");
            result2 = string_replace_all(result1, "//", "/");

            return (char *)result2.c_str();
        }

        return (char *)"";
    }

    char *program_directory()
    {
        char pdir[PATH_MAX + 1];
        ssize_t count = readlink("/proc/self/exe", pdir, PATH_MAX + 1);
        if (count !=  - 1)
        {
            static string result1;
            static string result2;

            result1 = dirname(pdir) + string("/");
            result2 = string_replace_all(result1, "//", "/");

            return (char *)result2.c_str();
        }

        return (char *)"";
    }

    char *temp_directory()
    {
        char const *env = getenv("TMPDIR");

        if (env == 0)
            env = "/tmp";

        static string result1;
        static string result2;

        result1 = env + string("/");
        result2 = string_replace_all(result1, "//", "/");

        return (char*)result2.c_str();
    }
}
