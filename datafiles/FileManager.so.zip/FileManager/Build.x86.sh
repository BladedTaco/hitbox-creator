cd /home/owner/Desktop/FileManager/
g++ -c -std=c++11 main.cpp -fPIC -m32
g++ main.o -o FileManager.x86/FileManager.so -shared -fPIC -m32
