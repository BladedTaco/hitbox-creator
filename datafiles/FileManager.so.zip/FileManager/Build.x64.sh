cd /home/owner/Desktop/FileManager/
g++ -c -std=c++11 main.cpp -fPIC -m64
g++ main.o -o FileManager.x64/FileManager.so -shared -fPIC -m64
