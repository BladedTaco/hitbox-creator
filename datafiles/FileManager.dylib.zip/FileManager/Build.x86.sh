cd /Users/owner/Desktop/FileManager/
g++ -c -std=c++11 main.cpp -m32
g++ main.o -o FileManager.x86/FileManager.dylib -shared -m32